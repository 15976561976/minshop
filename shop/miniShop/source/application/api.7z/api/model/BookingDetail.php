<?php

namespace app\api\model;
use app\common\model\BookingDetail as BookingDetailModel;

class BookingDetail extends BookingDetailModel
{
    /**
     * 隐藏字段
     * @var array
     */
    protected $hidden = [
        'wxapp_id',
        'create_time',
        'update_time'
    ];

    /**
     * 客户预约操作
     * @param $data
     * @param $userInfo
     * @return false|int
     */
    public function action($data, $userInfo)
    {
        $data['wxapp_id'] = self::$wxapp_id;
        $data['wx_user_id'] = $userInfo['user_id'];
        return $this->allowField(true)->save($data);
    }
}